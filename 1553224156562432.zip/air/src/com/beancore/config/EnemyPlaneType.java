package com.beancore.config;

public enum EnemyPlaneType {
	SMALL_ENEMY_PLANE, BIG_ENEMY_PLANE, BOSS_ENEMY_PLANE
}
